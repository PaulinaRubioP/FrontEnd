document.getElementById("btn1").addEventListener("click",function(){
	this.value="Logout";
});

function hide(element) {
    element.remove();
};


