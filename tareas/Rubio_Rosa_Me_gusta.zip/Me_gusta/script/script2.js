var me_gusta = 0;

function dar_like() {
    me_gusta++;
    var abc1 = document.querySelector(".cantidad"); //cantidad = <span class="cantidad">3</span>
    abc1.innerText = me_gusta;
}
var me_gusta2 = 0;

function dar_like2() {
    me_gusta2++;
    var abc1 = document.querySelector(".cantidad2"); //cantidad = <span class="cantidad">3</span>
    abc1.innerText = me_gusta2;
}
var me_gusta3 = 0;
function dar_like3() {
    me_gusta3++;
    var abc1 = document.querySelector(".cantidad3"); //cantidad = <span class="cantidad">3</span>
    abc1.innerText = me_gusta3;
}